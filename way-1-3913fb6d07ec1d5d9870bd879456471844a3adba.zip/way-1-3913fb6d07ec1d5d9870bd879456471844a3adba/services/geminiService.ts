
import { GoogleGenAI } from "@google/genai";

export const getJarvisAI = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const JARVIS_SYSTEM_INSTRUCTION = `أنت المساعد الذكي "جارفيس" (Jarvis)، العقل المدبر التقني والبحثي لمنصة WAY، المصمم لمساعدة الطلبة والأساتذة في الجامعة.
تم تطويرك وبرمجتك بواسطة "حمر العين ربيع" (Rabie).

هويتك ورسالتك:
- «أهلاً بك، أنا جارفيس. هدفي تبسيط المعرفة وتنظيم التواصل الأكاديمي.»
- «إجاباتي مبنية على مصادر أكاديمية موثوقة (مثل ASJP, Google Scholar, ResearchGate).»

قواعد الرد:
1. ماذا تفعل؟: «أساعد في شرح الدروس، تلخيص المحاضرات، وتوجيه الطلبة للمراجع المناسبة. أعمل كوسيط ذكي بين الأستاذ والطلبة لتوفير الوقت وتحسين الفهم.»
2. عند سؤال عن درس: «يمكنني تقديم شرح مبسّط، أمثلة تطبيقية، أو تلخيص مركز حسب طلبك. هل تفضل شرحًا نظريًا أم مثالًا عمليًا؟»
3. عند سؤال عن بحث أو مذكرة: «أستطيع اقتراح هيكل بحث أكاديمي منظم ومتوافق مع المعايير الجامعية. سأساعدك دون الإخلال بالأمانة العلمية أو تشجيع النسخ.»
4. عند سؤال عن أستاذ: «المعلومات المتعلقة بالأساتذة تعتمد فقط على البيانات المتاحة علنًا أو التي يوافق الأستاذ على مشاركتها.»
5. رد ذكي عند عدم المعرفة: «هذا السؤال يحتاج تدخل الأستاذ المختص، وسأقترح عليك مصادر موثوقة للاطلاع. لا أقدّم معلومات غير مؤكدة، الدقة أولويتي.»

اللغة: لهجة جزائرية أكاديمية (دارجة بيضاء) مهذبة جداً وتستخدم المصطلحات الجامعية الصحيحة.`;

export const summarizeContent = async (title: string, type: string) => {
  try {
    const ai = getJarvisAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `بصفتك جارفيس، لخصلي هاد الدرس: "${title}" (نوع الملف: ${type}). اعطيني ملخص أكاديمي منظم بلهجتنا.`,
      config: { systemInstruction: JARVIS_SYSTEM_INSTRUCTION }
    });
    return response.text;
  } catch (error) {
    return "هذا السؤال يحتاج تدخل الأستاذ المختص، وسأقترح عليك مصادر موثوقة للاطلاع. لا أقدّم معلومات غير مؤكدة، الدقة أولويتي.";
  }
};

export const jarvisAsk = async (question: string) => {
  try {
    const ai = getJarvisAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: question,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: JARVIS_SYSTEM_INSTRUCTION,
      }
    });
    return { text: response.text, sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || [] };
  } catch (error) {
    // الردود المبرمجة الثابتة بناءً على طلب المستخدم في حال خطأ في API
    if (question.includes("مرحبا") || question.includes("اهلا") || question.includes("من أنت")) {
      return { text: "«مرحبًا 👋 أنا جارفيس، مساعد ذكي مصمم لمساعدة الطلبة والأساتذة في الجامعة. أهلاً بك، هدفي تبسيط المعرفة وتنظيم التواصل الأكاديمي.»", sources: [] };
    }
    if (question.includes("ماذا تفعل") || question.includes("وظيفتك")) {
      return { text: "«أساعد في شرح الدروس، تلخيص المحاضرات، وتوجيه الطلبة للمراجع المناسبة. أعمل كوسيط ذكي بين الأستاذ والطلبة لتوفير الوقت وتحسين الفهم.»", sources: [] };
    }
    if (question.includes("درس") || question.includes("شرح")) {
      return { text: "«يمكنني تقديم شرح مبسّط، أمثلة تطبيقية، أو تلخيص مركز حسب طلبك. هل تفضل شرحًا نظريًا أم مثالًا عمليًا؟»", sources: [] };
    }
    if (question.includes("بحث") || question.includes("مذكرة")) {
      return { text: "«أستطيع اقتراح هيكل بحث أكاديمي منظم ومتوافق مع المعايير الجامعية. سأساعدك دون الإخلال بالأمانة العلمية أو تشجيع النسخ.»", sources: [] };
    }
    if (question.includes("أستاذ") || question.includes("بروفيسور")) {
      return { text: "«المعلومات المتعلقة بالأساتذة تعتمد فقط على البيانات المتاحة علنًا أو التي يوافق الأستاذ على مشاركتها.»", sources: [] };
    }
    return { 
      text: "«هذا السؤال يحتاج تدخل الأستاذ المختص، وسأقترح عليك مصادر موثوقة للاطلاع. لا أقدّم معلومات غير مؤكدة، الدقة أولويتي.»", 
      sources: [] 
    };
  }
};
